// Login
$('#sign-in').click((e) => {
	auth.signInWithPopup(provider).then((result) => {
		console.log('inicio de sesión exitoso');
	}).catch((error) => {
	  console.log(error,'error');
	});
});

$('#sign-out').click((e) => {
	auth.signOut().then(() => {
	  console.log('se cerro la sesión');
	}).catch((error) => {
	  console.log(error,'error');
	});
});

var signedIn = (user) => {
  console.log(user);
  $('#f-nombre').val(user.displayName);
  $('#sign-out , .card').show();
  $('#sign-in').hide();
}

var signedOut = () => {
  $('#sign-out , .card').hide();
  $('#sign-in').show();
}
