var signedIn = (user) => {
  // checkPermissions(user);
  console.log(user);
}

var signedOut = () => {
  console.log('visita');
  // withoutPermits();
}
