// Initialize Firebase
// aqui van tus credenciales de firebase

const provider = new firebase.auth.FacebookAuthProvider();
const auth     = firebase.auth();
const db       = firebase.database();
const storage  = firebase.storage();

//referencias
const users = db.ref('users');

// Auth State Changed
auth.onAuthStateChanged((user) => {
  if (user) {
		signedIn(user);
  } else {
		signedOut();
  }
});
